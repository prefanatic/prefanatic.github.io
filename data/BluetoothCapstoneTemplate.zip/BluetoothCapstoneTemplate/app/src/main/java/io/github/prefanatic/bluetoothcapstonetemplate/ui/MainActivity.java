package io.github.prefanatic.bluetoothcapstonetemplate.ui;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import java.io.IOException;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.github.prefanatic.bluetoothcapstonetemplate.R;
import io.github.prefanatic.bluetoothcapstonetemplate.RxBluetooth;

public class MainActivity extends AppCompatActivity {
    @Bind(R.id.toolbar) Toolbar toolbar;
    @Bind(R.id.fab) FloatingActionButton fab;

    private BluetoothSocket bluetoothSocket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        setSupportActionBar(toolbar);

    }

    @OnClick(R.id.fab)
    public void onFabClicked() {
        DeviceListDialog deviceListDialog = new DeviceListDialog();

        deviceListDialog.getDevice().subscribe(this::deviceSelected);
        deviceListDialog.show(getFragmentManager(), "deviceList");
    }

    private void deviceSelected(BluetoothDevice device) {
        RxBluetooth.connectAsClient(device)
                .subscribe(socket -> {
                    message("Connected");

                    bluetoothSocket = socket;
                    RxBluetooth.readInputStream(socket)
                            .subscribe(this::onBytesReceived);
                }, err -> {
                    message("Disconnected");
                });
    }

    private void onBytesReceived(byte[] data) {
        for (int i = 0; i < data.length; i++) {
            int val = data[i] & 0xFF;

            // Do what you need to do with the data here.
        }
    }

    private void message(String msg) {
        Snackbar.make(toolbar, msg, Snackbar.LENGTH_LONG).show();
    }

    @Override
    protected void onDestroy() {
        if (bluetoothSocket != null) {
            try {
                bluetoothSocket.close();
            } catch (IOException e) {
            }
        }

        super.onDestroy();
    }
}
